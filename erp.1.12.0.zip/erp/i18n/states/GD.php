<?php

global $states;

$states['GD'] = [
    'CARRIACOUANDPETITMARTINIQUE' => __( 'Carriacou and Petit Martinique', 'erp' ),
    'SAINTANDREW'                 => __( 'Saint Andrew', 'erp' ),
    'SAINTDAVID'                  => __( 'Saint David', 'erp' ),
    'SAINTGEORGE'                 => __( 'Saint George', 'erp' ),
    'SAINTJOHN'                   => __( 'Saint John', 'erp' ),
    'SAINTMARK'                   => __( 'Saint Mark', 'erp' ),
    'SAINTPATRICK'                => __( 'Saint Patrick', 'erp' ),
];

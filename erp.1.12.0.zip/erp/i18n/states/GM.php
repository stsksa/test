<?php

global $states;

$states['GM'] = [
    'BANJUL'       => __( 'Banjul', 'erp' ),
    'CENTRALRIVER' => __( 'Central River', 'erp' ),
    'LOWERRIVER'   => __( 'Lower River', 'erp' ),
    'NORTHBANK'    => __( 'North Bank', 'erp' ),
    'UPPERRIVER'   => __( 'Upper River', 'erp' ),
    'WESTERN'      => __( 'Western', 'erp' ),
];

<?php

global $states;

$states['KG'] = [
    'BATKENOBLASTY'     => __( 'Batken Oblasty', 'erp' ),
    'BISHKEKSHAARY'     => __( 'Bishkek Shaary', 'erp' ),
    'CHUYOBLASTY'       => __( 'Chuy Oblasty', 'erp' ),
    'JALAL-ABADOBLASTY' => __( 'Jalal-Abad Oblasty', 'erp' ),
    'NARYNOBLASTY'      => __( 'Naryn Oblasty', 'erp' ),
    'OSHOBLASTY'        => __( 'Osh Oblasty', 'erp' ),
    'TALASOBLASTY'      => __( 'Talas Oblasty', 'erp' ),
    'YSYK-KOLOBLASTY'   => __( 'Ysyk-Kol Oblasty', 'erp' ),
];

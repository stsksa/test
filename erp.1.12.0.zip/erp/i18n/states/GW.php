<?php

global $states;

$states['GW'] = [
    'BAFATA'  => __( 'Bafata', 'erp' ),
    'BIOMBO'  => __( 'Biombo', 'erp' ),
    'BISSAU'  => __( 'Bissau', 'erp' ),
    'BOLAMA'  => __( 'Bolama', 'erp' ),
    'CACHEU'  => __( 'Cacheu', 'erp' ),
    'GABU'    => __( 'Gabu', 'erp' ),
    'OIO'     => __( 'Oio', 'erp' ),
    'QUINARA' => __( 'Quinara', 'erp' ),
    'TOMBALI' => __( 'Tombali', 'erp' ),
];

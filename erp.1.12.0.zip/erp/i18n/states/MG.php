<?php

global $states;

$states['MG'] = [
    'ANTANANARIVO' => __( 'Antananarivo', 'erp' ),
    'ANTSIRANANA'  => __( 'Antsiranana', 'erp' ),
    'FIANARANTSOA' => __( 'Fianarantsoa', 'erp' ),
    'MAHAJANGA'    => __( 'Mahajanga', 'erp' ),
    'TOAMASINA'    => __( 'Toamasina', 'erp' ),
    'TOLIARA'      => __( 'Toliara', 'erp' ),
];

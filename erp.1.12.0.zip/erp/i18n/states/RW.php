<?php

global $states;

$states['RW'] = [
    'BUTARE'       => __( 'Butare', 'erp' ),
    'BYUMBA'       => __( 'Byumba', 'erp' ),
    'CYANGUGU'     => __( 'Cyangugu', 'erp' ),
    'GIKONGORO'    => __( 'Gikongoro', 'erp' ),
    'GISENYI'      => __( 'Gisenyi', 'erp' ),
    'GITARAMA'     => __( 'Gitarama', 'erp' ),
    'KIBUNGO'      => __( 'Kibungo', 'erp' ),
    'KIBUYE'       => __( 'Kibuye', 'erp' ),
    'KIGALIRURALE' => __( 'Kigali Rurale', 'erp' ),
    'KIGALI-VILLE' => __( 'Kigali-ville', 'erp' ),
    'UMUTARA'      => __( 'Umutara', 'erp' ),
    'RUHENGERI'    => __( 'Ruhengeri', 'erp' ),
];

<?php

global $states;

$states['QA'] = [
    'ADDAWHAH'         => __( 'Ad Dawhah', 'erp' ),
    'ALGHUWAYRIYAH'    => __( 'Al Ghuwayriyah', 'erp' ),
    'ALJUMAYLIYAH'     => __( 'Al Jumayliyah', 'erp' ),
    'ALKHAWR'          => __( 'Al Khawr', 'erp' ),
    'ALWAKRAH'         => __( 'Al Wakrah', 'erp' ),
    'ARRAYYAN'         => __( 'Ar Rayyan', 'erp' ),
    'JARAYANALBATINAH' => __( 'Jarayan al Batinah', 'erp' ),
    'MADINATASHSHAMAL' => __( 'Madinat ash Shamal', 'erp' ),
    "UMMSA'ID"         => __( "Umm Sa'id", 'erp' ),
    'UMMSALAL'         => __( 'Umm Salal', 'erp' ),
];

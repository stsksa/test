<?php

global $states;

$states['ZM'] = [
    'CENTRAL'       => __( 'Central', 'erp' ),
    'COPPERBELT'    => __( 'Copperbelt', 'erp' ),
    'EASTERN'       => __( 'Eastern', 'erp' ),
    'LUAPULA'       => __( 'Luapula', 'erp' ),
    'LUSAKA'        => __( 'Lusaka', 'erp' ),
    'NORTHERN'      => __( 'Northern', 'erp' ),
    'NORTH-WESTERN' => __( 'North-Western', 'erp' ),
    'SOUTHERN'      => __( 'Southern', 'erp' ),
    'WESTERN'       => __( 'Western', 'erp' ),
];

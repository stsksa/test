<?php

global $states;

$states['KM'] = [
    'GRANDECOMORE(NJAZIDJA)' => __( 'Grande Comore (Njazidja)', 'erp' ),
    'ANJOUAN(NZWANI)'        => __( 'Anjouan (Nzwani)', 'erp' ),
    'MOHELI(MWALI)'          => __( 'Moheli (Mwali)', 'erp' ),
];

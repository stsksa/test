<?php

global $states;

$states['SN'] = [
    'DAKAR'       => __( 'Dakar', 'erp' ),
    'DIOURBEL'    => __( 'Diourbel', 'erp' ),
    'FATICK'      => __( 'Fatick', 'erp' ),
    'KAOLACK'     => __( 'Kaolack', 'erp' ),
    'KOLDA'       => __( 'Kolda', 'erp' ),
    'LOUGA'       => __( 'Louga', 'erp' ),
    'MATAM'       => __( 'Matam', 'erp' ),
    'SAINT-LOUIS' => __( 'Saint-Louis', 'erp' ),
    'TAMBACOUNDA' => __( 'Tambacounda', 'erp' ),
    'THIES'       => __( 'Thies', 'erp' ),
    'ZIGUINCHOR'  => __( 'Ziguinchor', 'erp' ),
];

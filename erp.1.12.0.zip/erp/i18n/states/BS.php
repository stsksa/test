<?php

global $states;

$states['BS'] = [
    'ACKLINSANDCROOKEDISLANDS'    => __( 'Acklins and Crooked Islands', 'erp' ),
    'BIMINI'                      => __( 'Bimini', 'erp' ),
    'CATISLAND'                   => __( 'Cat Island', 'erp' ),
    'EXUMA'                       => __( 'Exuma', 'erp' ),
    'FREEPORT'                    => __( 'Freeport', 'erp' ),
    'FRESHCREEK'                  => __( 'Fresh Creek', 'erp' ),
    "GOVERNOR'SHARBOUR"           => __( "Governor's Harbour", 'erp' ),
    'GREENTURTLECAY'              => __( 'Green Turtle Cay', 'erp' ),
    'HARBOURISLAND'               => __( 'Harbour Island', 'erp' ),
    'HIGHROCK'                    => __( 'High Rock', 'erp' ),
    'INAGUA'                      => __( 'Inagua', 'erp' ),
    'KEMPSBAY'                    => __( 'Kemps Bay', 'erp' ),
    'LONGISLAND'                  => __( 'Long Island', 'erp' ),
    'MARSHHARBOUR'                => __( 'Marsh Harbour', 'erp' ),
    'MAYAGUANA'                   => __( 'Mayaguana', 'erp' ),
    'NEWPROVIDENCE'               => __( 'New Providence', 'erp' ),
    'NICHOLLSTOWNANDBERRYISLANDS' => __( 'Nichollstown and Berry Islands', 'erp' ),
    'RAGGEDISLAND'                => __( 'Ragged Island', 'erp' ),
    'ROCKSOUND'                   => __( 'Rock Sound', 'erp' ),
    'SANDYPOINT'                  => __( 'Sandy Point', 'erp' ),
    'SANSALVADORANDRUMCAY'        => __( 'San Salvador and Rum Cay', 'erp' ),
];

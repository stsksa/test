<?php

global $states;

$states['BB'] = [
    'CHRISTCHURCH' => __( 'Christ Church', 'erp' ),
    'SAINTANDREW'  => __( 'Saint Andrew', 'erp' ),
    'SAINTGEORGE'  => __( 'Saint George', 'erp' ),
    'SAINTJAMES'   => __( 'Saint James', 'erp' ),
    'SAINTJOHN'    => __( 'Saint John', 'erp' ),
    'SAINTJOSEPH'  => __( 'Saint Joseph', 'erp' ),
    'SAINTLUCY'    => __( 'Saint Lucy', 'erp' ),
    'SAINTMICHAEL' => __( 'Saint Michael', 'erp' ),
    'SAINTPETER'   => __( 'Saint Peter', 'erp' ),
    'SAINTPHILIP'  => __( 'Saint Philip', 'erp' ),
    'SAINTTHOMAS'  => __( 'Saint Thomas', 'erp' ),
];

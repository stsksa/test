<?php

global $states;

$states['LS'] = [
'BEREA'        => __( 'Berea', 'erp' ),
'BUTHA-BUTHE'  => __( 'Butha-Buthe', 'erp' ),
'LERIBE'       => __( 'Leribe', 'erp' ),
'MAFETENG'     => __( 'Mafeteng', 'erp' ),
'MASERU'       => __( 'Maseru', 'erp' ),
"MOHALE'SHOEK" => __( "Mohale's Hoek", 'erp' ),
'MOKHOTLONG'   => __( 'Mokhotlong', 'erp' ),
"QACHA'SNEK"   => __( "Qacha's Nek", 'erp' ),
'QUTHING'      => __( 'Quthing', 'erp' ),
'THABA-TSEKA'  => __( 'Thaba-Tseka', 'erp' ),
];

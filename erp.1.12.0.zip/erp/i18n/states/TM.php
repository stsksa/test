<?php

global $states;

$states['TM'] = [
    'AHALWELAYATY(ASHGABAT)'     => __( 'Ahal Welayaty (Ashgabat)', 'erp' ),
    'BALKANWELAYATY(BALKANABAT)' => __( 'Balkan Welayaty (Balkanabat)', 'erp' ),
    'DASHOGUZWELAYATY'           => __( 'Dashoguz Welayaty', 'erp' ),
    'LEBAPWELAYATY(TURKMENABAT)' => __( 'Lebap Welayaty (Turkmenabat)', 'erp' ),
    'MARYWELAYATY'               => __( 'Mary Welayaty', 'erp' ),
];

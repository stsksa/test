<?php

global $states;

$states['LU'] = [
    'DIEKIRCH'     => __( 'Diekirch', 'erp' ),
    'GREVENMACHER' => __( 'Grevenmacher', 'erp' ),
    'LUXEMBOURG'   => __( 'Luxembourg', 'erp' ),
];

<?php

global $states;

$states['SO'] = [
    'AWDAL'            => __( 'Awdal', 'erp' ),
    'BAKOOL'           => __( 'Bakool', 'erp' ),
    'BANAADIR'         => __( 'Banaadir', 'erp' ),
    'BARI'             => __( 'Bari', 'erp' ),
    'BAY'              => __( 'Bay', 'erp' ),
    'GALGUDUUD'        => __( 'Galguduud', 'erp' ),
    'GEDO'             => __( 'Gedo', 'erp' ),
    'HIIRAAN'          => __( 'Hiiraan', 'erp' ),
    'JUBBADADHEXE'     => __( 'Jubbada Dhexe', 'erp' ),
    'JUBBADAHOOSE'     => __( 'Jubbada Hoose', 'erp' ),
    'MUDUG'            => __( 'Mudug', 'erp' ),
    'NUGAAL'           => __( 'Nugaal', 'erp' ),
    'SANAAG'           => __( 'Sanaag', 'erp' ),
    'SHABEELLAHADHEXE' => __( 'Shabeellaha Dhexe', 'erp' ),
    'SHABEELLAHAHOOSE' => __( 'Shabeellaha Hoose', 'erp' ),
    'SOOL'             => __( 'Sool', 'erp' ),
    'TOGDHEER'         => __( 'Togdheer', 'erp' ),
    'WOQOOYIGALBEED'   => __( 'Woqooyi Galbeed', 'erp' ),
];

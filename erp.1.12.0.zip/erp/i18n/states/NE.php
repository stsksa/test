<?php

global $states;

$states['NE'] = [
    'AGADEZ'    => __( 'Agadez', 'erp' ),
    'DIFFA'     => __( 'Diffa', 'erp' ),
    'DOSSO'     => __( 'Dosso', 'erp' ),
    'MARADI'    => __( 'Maradi', 'erp' ),
    'NIAMEY'    => __( 'Niamey', 'erp' ),
    'TAHOUA'    => __( 'Tahoua', 'erp' ),
    'TILLABERI' => __( 'Tillaberi', 'erp' ),
    'ZINDER'    => __( 'Zinder', 'erp' ),
];

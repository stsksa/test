<?php

global $states;

$states['BN'] = [
    'BELAIT'         => __( 'Belait', 'erp' ),
    'BRUNEIANDMUARA' => __( 'Brunei and Muara', 'erp' ),
    'TEMBURONG'      => __( 'Temburong', 'erp' ),
    'TUTONG'         => __( 'Tutong', 'erp' ),
];

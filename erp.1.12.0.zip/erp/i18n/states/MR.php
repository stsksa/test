<?php

global $states;

$states['MR'] = [
    'ADRAR'             => __( 'Adrar', 'erp' ),
    'ASSABA'            => __( 'Assaba', 'erp' ),
    'BRAKNA'            => __( 'Brakna', 'erp' ),
    'DAKHLETNOUADHIBOU' => __( 'Dakhlet Nouadhibou', 'erp' ),
    'GORGOL'            => __( 'Gorgol', 'erp' ),
    'GUIDIMAKA'         => __( 'Guidimaka', 'erp' ),
    'HODHECHCHARGUI'    => __( 'Hodh Ech Chargui', 'erp' ),
    'HODHELGHARBI'      => __( 'Hodh El Gharbi', 'erp' ),
    'INCHIRI'           => __( 'Inchiri', 'erp' ),
    'NOUAKCHOTT'        => __( 'Nouakchott', 'erp' ),
    'TAGANT'            => __( 'Tagant', 'erp' ),
    'TIRISZEMMOUR'      => __( 'Tiris Zemmour', 'erp' ),
    'TRARZA'            => __( 'Trarza', 'erp' ),
];

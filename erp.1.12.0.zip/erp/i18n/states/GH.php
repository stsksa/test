<?php

global $states;

$states['GH'] = [
    'ASHANTI'      => __( 'Ashanti', 'erp' ),
    'BRONG-AHAFO'  => __( 'Brong-Ahafo', 'erp' ),
    'CENTRAL'      => __( 'Central', 'erp' ),
    'EASTERN'      => __( 'Eastern', 'erp' ),
    'GREATERACCRA' => __( 'Greater Accra', 'erp' ),
    'NORTHERN'     => __( 'Northern', 'erp' ),
    'UPPEREAST'    => __( 'Upper East', 'erp' ),
    'UPPERWEST'    => __( 'Upper West', 'erp' ),
    'VOLTA'        => __( 'Volta', 'erp' ),
    'WESTERN'      => __( 'Western', 'erp' ),
];

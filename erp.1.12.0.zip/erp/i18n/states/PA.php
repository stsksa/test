<?php

global $states;

$states['PA'] = [
    'BOCASDELTORO' => __( 'Bocas del Toro', 'erp' ),
    'CHIRIQUI'     => __( 'Chiriqui', 'erp' ),
    'COCLE'        => __( 'Cocle', 'erp' ),
    'COLON'        => __( 'Colon', 'erp' ),
    'DARIEN'       => __( 'Darien', 'erp' ),
    'HERRERA'      => __( 'Herrera', 'erp' ),
    'LOSSANTOS'    => __( 'Los Santos', 'erp' ),
    'PANAMA'       => __( 'Panama', 'erp' ),
    'SANBLAS'      => __( 'San Blas', 'erp' ),
    'VERAGUAS'     => __( 'Veraguas', 'erp' ),
];

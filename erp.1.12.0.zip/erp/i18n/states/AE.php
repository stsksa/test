<?php

global $states;

$states['AE'] = [
    'ABUDHABI'      => __( 'Abu Dhabi', 'erp' ),
    "'AJMAN"        => __( "'Ajman", 'erp' ),
    'ALFUJAYRAH'    => __( 'Al Fujayrah', 'erp' ),
    'SHARJAH'       => __( 'Sharjah', 'erp' ),
    'DUBAI'         => __( 'Dubai', 'erp' ),
    "RA'SALKHAYMAH" => __( "Ra's al Khaymah", 'erp' ),
    'UMMALQAYWAYN'  => __( 'Umm al Qaywayn', 'erp' ),
];

<?php

global $states;

$states['EC'] = [
    'AZUAY'            => __( 'Azuay', 'erp' ),
    'BOLIVAR'          => __( 'Bolivar', 'erp' ),
    'CANAR'            => __( 'Canar', 'erp' ),
    'CARCHI'           => __( 'Carchi', 'erp' ),
    'CHIMBORAZO'       => __( 'Chimborazo', 'erp' ),
    'COTOPAXI'         => __( 'Cotopaxi', 'erp' ),
    'ELORO'            => __( 'El Oro', 'erp' ),
    'ESMERALDAS'       => __( 'Esmeraldas', 'erp' ),
    'GALAPAGOS'        => __( 'Galapagos', 'erp' ),
    'GUAYAS'           => __( 'Guayas', 'erp' ),
    'IMBABURA'         => __( 'Imbabura', 'erp' ),
    'LOJA'             => __( 'Loja', 'erp' ),
    'LOSRIOS'          => __( 'Los Rios', 'erp' ),
    'MANABI'           => __( 'Manabi', 'erp' ),
    'MORONA-SANTIAGO'  => __( 'Morona-Santiago', 'erp' ),
    'NAPO'             => __( 'Napo', 'erp' ),
    'ORELLANA'         => __( 'Orellana', 'erp' ),
    'PASTAZA'          => __( 'Pastaza', 'erp' ),
    'PICHINCHA'        => __( 'Pichincha', 'erp' ),
    'SUCUMBIOS'        => __( 'Sucumbios', 'erp' ),
    'TUNGURAHUA'       => __( 'Tungurahua', 'erp' ),
    'ZAMORA-CHINCHIPE' => __( 'Zamora-Chinchipe', 'erp' ),
];

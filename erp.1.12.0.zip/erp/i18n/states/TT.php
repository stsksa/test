<?php

global $states;

$states['TT'] = [
    'COUVA'         => __( 'Couva', 'erp' ),
    'DIEGOMARTIN'   => __( 'Diego Martin', 'erp' ),
    'MAYARO'        => __( 'Mayaro', 'erp' ),
    'PENAL'         => __( 'Penal', 'erp' ),
    'PRINCESTOWN'   => __( 'Princes Town', 'erp' ),
    'SANGREGRANDE'  => __( 'Sangre Grande', 'erp' ),
    'SANJUAN'       => __( 'San Juan', 'erp' ),
    'SIPARIA'       => __( 'Siparia', 'erp' ),
    'TUNAPUNA'      => __( 'Tunapuna', 'erp' ),
    'PORT-OF-SPAIN' => __( 'Port-of-Spain', 'erp' ),
    'SANFERNANDO'   => __( 'San Fernando', 'erp' ),
    'ARIMA'         => __( 'Arima', 'erp' ),
    'POINTFORTIN'   => __( 'Point Fortin', 'erp' ),
    'CHAGUANAS'     => __( 'Chaguanas', 'erp' ),
    'TOBAGO'        => __( 'Tobago', 'erp' ),
];

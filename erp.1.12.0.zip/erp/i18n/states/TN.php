<?php

global $states;

$states['TN'] = [
    'ARIANA(ARYANAH)'        => __( 'Ariana (Aryanah)', 'erp' ),
    'BEJA(BAJAH)'            => __( 'Beja (Bajah)', 'erp' ),
    "BENAROUS(BIN'ARUS)"     => __( "Ben Arous (Bin 'Arus)", 'erp' ),
    'BIZERTE(BANZART)'       => __( 'Bizerte (Banzart)', 'erp' ),
    'GABES(QABIS)'           => __( 'Gabes (Qabis)', 'erp' ),
    'GAFSA(QAFSAH)'          => __( 'Gafsa (Qafsah)', 'erp' ),
    'JENDOUBA(JUNDUBAH)'     => __( 'Jendouba (Jundubah)', 'erp' ),
    'KAIROUAN(ALQAYRAWAN)'   => __( 'Kairouan (Al Qayrawan)', 'erp' ),
    'KASSERINE(ALQASRAYN)'   => __( 'Kasserine (Al Qasrayn)', 'erp' ),
    'KEBILI(QIBILI)'         => __( 'Kebili (Qibili)', 'erp' ),
    'KEF(ALKAF)'             => __( 'Kef (Al Kaf)', 'erp' ),
    'MAHDIA(ALMAHDIYAH)'     => __( 'Mahdia (Al Mahdiyah)', 'erp' ),
    'MANOUBA(MANUBAH)'       => __( 'Manouba (Manubah)', 'erp' ),
    'MEDENINE(MADANIN)'      => __( 'Medenine (Madanin)', 'erp' ),
    'MONASTIR(ALMUNASTIR)'   => __( 'Monastir (Al Munastir)', 'erp' ),
    'NABEUL(NABUL)'          => __( 'Nabeul (Nabul)', 'erp' ),
    'SFAX(SAFAQIS)'          => __( 'Sfax (Safaqis)', 'erp' ),
    'SIDIBOUZID(SIDIBUZAYD)' => __( 'Sidi Bou Zid (Sidi Bu Zayd)', 'erp' ),
    'SILIANA(SILYANAH)'      => __( 'Siliana (Silyanah)', 'erp' ),
    'SOUSSE(SUSAH)'          => __( 'Sousse (Susah)', 'erp' ),
    'TATAOUINE(TATAWIN)'     => __( 'Tataouine (Tatawin)', 'erp' ),
    'TOZEUR(TAWZAR)'         => __( 'Tozeur (Tawzar)', 'erp' ),
    'TUNIS'                  => __( 'Tunis', 'erp' ),
    'ZAGHOUAN(ZAGHWAN)'      => __( 'Zaghouan (Zaghwan)', 'erp' ),
];

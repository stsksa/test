<?php

global $states;

$states['GT'] = [
    'ALTAVERAPAZ'    => __( 'Alta Verapaz', 'erp' ),
    'BAJAVERAPAZ'    => __( 'Baja Verapaz', 'erp' ),
    'CHIMALTENANGO'  => __( 'Chimaltenango', 'erp' ),
    'CHIQUIMULA'     => __( 'Chiquimula', 'erp' ),
    'ELPROGRESO'     => __( 'El Progreso', 'erp' ),
    'ESCUINTLA'      => __( 'Escuintla', 'erp' ),
    'GUATEMALA'      => __( 'Guatemala', 'erp' ),
    'HUEHUETENANGO'  => __( 'Huehuetenango', 'erp' ),
    'IZABAL'         => __( 'Izabal', 'erp' ),
    'JALAPA'         => __( 'Jalapa', 'erp' ),
    'JUTIAPA'        => __( 'Jutiapa', 'erp' ),
    'PETEN'          => __( 'Peten', 'erp' ),
    'QUETZALTENANGO' => __( 'Quetzaltenango', 'erp' ),
    'QUICHE'         => __( 'Quiche', 'erp' ),
    'RETALHULEU'     => __( 'Retalhuleu', 'erp' ),
    'SACATEPEQUEZ'   => __( 'Sacatepequez', 'erp' ),
    'SANMARCOS'      => __( 'San Marcos', 'erp' ),
    'SANTAROSA'      => __( 'Santa Rosa', 'erp' ),
    'SOLOLA'         => __( 'Solola', 'erp' ),
    'SUCHITEPEQUEZ'  => __( 'Suchitepequez', 'erp' ),
    'TOTONICAPAN'    => __( 'Totonicapan', 'erp' ),
    'ZACAPA'         => __( 'Zacapa', 'erp' ),
];

<?php

global $states;

$states['BT'] = [
    'BUMTHANG'        => __( 'Bumthang', 'erp' ),
    'CHUKHA'          => __( 'Chukha', 'erp' ),
    'DAGANA'          => __( 'Dagana', 'erp' ),
    'GASA'            => __( 'Gasa', 'erp' ),
    'HAA'             => __( 'Haa', 'erp' ),
    'LHUNTSE'         => __( 'Lhuntse', 'erp' ),
    'MONGAR'          => __( 'Mongar', 'erp' ),
    'PARO'            => __( 'Paro', 'erp' ),
    'PEMAGATSHEL'     => __( 'Pemagatshel', 'erp' ),
    'PUNAKHA'         => __( 'Punakha', 'erp' ),
    'SAMDRUPJONGKHAR' => __( 'Samdrup Jongkhar', 'erp' ),
    'SAMTSE'          => __( 'Samtse', 'erp' ),
    'SARPANG'         => __( 'Sarpang', 'erp' ),
    'THIMPHU'         => __( 'Thimphu', 'erp' ),
    'TRASHIGANG'      => __( 'Trashigang', 'erp' ),
    'TRASHIYANGSTE'   => __( 'Trashiyangste', 'erp' ),
    'TRONGSA'         => __( 'Trongsa', 'erp' ),
    'TSIRANG'         => __( 'Tsirang', 'erp' ),
    'WANGDUEPHODRANG' => __( 'Wangdue Phodrang', 'erp' ),
    'ZHEMGANG'        => __( 'Zhemgang', 'erp' ),
];

<?php

global $states;

$states['BM'] = [
    'DEVONSHIRE'    => __( 'Devonshire', 'erp' ),
    'HAMILTON'      => __( 'Hamilton', 'erp' ),
    'HAMILTON'      => __( 'Hamilton', 'erp' ),
    'PAGET'         => __( 'Paget', 'erp' ),
    'PEMBROKE'      => __( 'Pembroke', 'erp' ),
    'SAINTGEORGE'   => __( 'Saint George', 'erp' ),
    "SAINTGEORGE'S" => __( "Saint George's", 'erp' ),
    'SANDYS'        => __( 'Sandys', 'erp' ),
    "SMITH'S"       => __( "Smith's", 'erp' ),
    'SOUTHAMPTON'   => __( 'Southampton', 'erp' ),
    'WARWICK'       => __( 'Warwick', 'erp' ),
];

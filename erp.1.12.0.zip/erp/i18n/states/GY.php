<?php

global $states;

$states['GY'] = [
    'BARIMA-WAINI'                  => __( 'Barima-Waini', 'erp' ),
    'CUYUNI-MAZARUNI'               => __( 'Cuyuni-Mazaruni', 'erp' ),
    'DEMERARA-MAHAICA'              => __( 'Demerara-Mahaica', 'erp' ),
    'EASTBERBICE-CORENTYNE'         => __( 'East Berbice-Corentyne', 'erp' ),
    'ESSEQUIBOISLANDS-WESTDEMERARA' => __( 'Essequibo Islands-West Demerara', 'erp' ),
    'MAHAICA-BERBICE'               => __( 'Mahaica-Berbice', 'erp' ),
    'POMEROON-SUPENAAM'             => __( 'Pomeroon-Supenaam', 'erp' ),
    'POTARO-SIPARUNI'               => __( 'Potaro-Siparuni', 'erp' ),
    'UPPERDEMERARA-BERBICE'         => __( 'Upper Demerara-Berbice', 'erp' ),
    'UPPERTAKUTU-UPPERESSEQUIBO'    => __( 'Upper Takutu-Upper Essequibo', 'erp' ),
];

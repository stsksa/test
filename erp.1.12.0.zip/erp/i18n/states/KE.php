<?php

global $states;

$states['KE'] = [
    'CENTRAL'      => __( 'Central', 'erp' ),
    'COAST'        => __( 'Coast', 'erp' ),
    'EASTERN'      => __( 'Eastern', 'erp' ),
    'NAIROBIAREA'  => __( 'Nairobi Area', 'erp' ),
    'NORTHEASTERN' => __( 'North Eastern', 'erp' ),
    'NYANZA'       => __( 'Nyanza', 'erp' ),
    'RIFTVALLEY'   => __( 'Rift Valley', 'erp' ),
    'WESTERN'      => __( 'Western', 'erp' ),
];

<?php

global $states;

$states['BY'] = [
    'BREST'      => __( 'Brest', 'erp' ),
    'HOMYEL'     => __( 'Homyel', 'erp' ),
    'HORADMINSK' => __( 'Horad Minsk', 'erp' ),
    'HRODNA'     => __( 'Hrodna', 'erp' ),
    'MAHILYOW'   => __( 'Mahilyow', 'erp' ),
    'MINSK'      => __( 'Minsk', 'erp' ),
    'VITSYEBSK'  => __( 'Vitsyebsk', 'erp' ),
];

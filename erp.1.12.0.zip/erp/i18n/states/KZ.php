<?php

global $states;

$states['KZ'] = [
    'ALMATYOBLYSY'             => __( 'Almaty Oblysy', 'erp' ),
    'ALMATYQALASY'             => __( 'Almaty Qalasy', 'erp' ),
    'AQMOLAOBLYSY'             => __( 'Aqmola Oblysy', 'erp' ),
    'AQTOBEOBLYSY'             => __( 'Aqtobe Oblysy', 'erp' ),
    'ASTANAQALASY'             => __( 'Astana Qalasy', 'erp' ),
    'ATYRAUOBLYSY'             => __( 'Atyrau Oblysy', 'erp' ),
    'BATYSQAZAQSTANOBLYSY'     => __( 'Batys Qazaqstan Oblysy', 'erp' ),
    'BAYQONGYRQALASY'          => __( 'Bayqongyr Qalasy', 'erp' ),
    'MANGGHYSTAUOBLYSY'        => __( 'Mangghystau Oblysy', 'erp' ),
    'ONGTUSTIKQAZAQSTANOBLYSY' => __( 'Ongtustik Qazaqstan Oblysy', 'erp' ),
    'PAVLODAROBLYSY'           => __( 'Pavlodar Oblysy', 'erp' ),
    'QARAGHANDYOBLYSY'         => __( 'Qaraghandy Oblysy', 'erp' ),
    'QOSTANAYOBLYSY'           => __( 'Qostanay Oblysy', 'erp' ),
    'QYZYLORDAOBLYSY'          => __( 'Qyzylorda Oblysy', 'erp' ),
    'SHYGHYSQAZAQSTANOBLYSY'   => __( 'Shyghys Qazaqstan Oblysy', 'erp' ),
    'SOLTUSTIKQAZAQSTANOBLYSY' => __( 'Soltustik Qazaqstan Oblysy', 'erp' ),
    'ZHAMBYLOBLYSY'            => __( 'Zhambyl Oblysy', 'erp' ),
];

<?php

global $states;

$states['SV'] = [
    'AHUACHAPAN'   => __( 'Ahuachapan', 'erp' ),
    'CABANAS'      => __( 'Cabanas', 'erp' ),
    'CHALATENANGO' => __( 'Chalatenango', 'erp' ),
    'CUSCATLAN'    => __( 'Cuscatlan', 'erp' ),
    'LALIBERTAD'   => __( 'La Libertad', 'erp' ),
    'LAPAZ'        => __( 'La Paz', 'erp' ),
    'LAUNION'      => __( 'La Union', 'erp' ),
    'MORAZAN'      => __( 'Morazan', 'erp' ),
    'SANMIGUEL'    => __( 'San Miguel', 'erp' ),
    'SANSALVADOR'  => __( 'San Salvador', 'erp' ),
    'SANTAANA'     => __( 'Santa Ana', 'erp' ),
    'SANVICENTE'   => __( 'San Vicente', 'erp' ),
    'SONSONATE'    => __( 'Sonsonate', 'erp' ),
    'USULUTAN'     => __( 'Usulutan', 'erp' ),
];

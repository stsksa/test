<?php

global $states;

$states['PK'] = [
    'BALOCHISTAN'                      => __( 'Balochistan', 'erp' ),
    'NORTH-WESTFRONTIERPROVINCE'       => __( 'North-West Frontier Province', 'erp' ),
    'PUNJAB'                           => __( 'Punjab', 'erp' ),
    'SINDH'                            => __( 'Sindh', 'erp' ),
    'ISLAMABADCAPITALTERRITORY'        => __( 'Islamabad Capital Territory', 'erp' ),
    'FEDERALLYADMINISTEREDTRIBALAREAS' => __( 'Federally Administered Tribal Areas', 'erp' ),
];

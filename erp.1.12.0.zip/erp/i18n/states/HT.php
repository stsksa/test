<?php

global $states;

$states['HT'] = [
    'ARTIBONITE' => __( 'Artibonite', 'erp' ),
    'CENTRE'     => __( 'Centre', 'erp' ),
    "GRAND'ANSE" => __( "Grand 'Anse", 'erp' ),
    'NORD'       => __( 'Nord', 'erp' ),
    'NORD-EST'   => __( 'Nord-Est', 'erp' ),
    'NORD-OUEST' => __( 'Nord-Ouest', 'erp' ),
    'OUEST'      => __( 'Ouest', 'erp' ),
    'SUD'        => __( 'Sud', 'erp' ),
    'SUD-EST'    => __( 'Sud-Est', 'erp' ),
];

<?php

global $states;

$states['YE'] = [
    'ABYAN'      => __( 'Abyan', 'erp' ),
    "'ADAN"      => __( "'Adan", 'erp' ),
    "ADDALI'"    => __( "Ad Dali'", 'erp' ),
    "ALBAYDA'"   => __( "Al Bayda'", 'erp' ),
    'ALHUDAYDAH' => __( 'Al Hudaydah', 'erp' ),
    'ALJAWF'     => __( 'Al Jawf', 'erp' ),
    'ALMAHRAH'   => __( 'Al Mahrah', 'erp' ),
    'ALMAHWIT'   => __( 'Al Mahwit', 'erp' ),
    "'AMRAN"     => __( "'Amran", 'erp' ),
    'DHAMAR'     => __( 'Dhamar', 'erp' ),
    'HADRAMAWT'  => __( 'Hadramawt', 'erp' ),
    'HAJJAH'     => __( 'Hajjah', 'erp' ),
    'IBB'        => __( 'Ibb', 'erp' ),
    'LAHIJ'      => __( 'Lahij', 'erp' ),
    "MA'RIB"     => __( "Ma'rib", 'erp' ),
    "SA'DAH"     => __( "Sa'dah", 'erp' ),
    "SAN'A'"     => __( "San'a'", 'erp' ),
    'SHABWAH'    => __( 'Shabwah', 'erp' ),
    "TA'IZZ"     => __( "Ta'izz", 'erp' ),
];

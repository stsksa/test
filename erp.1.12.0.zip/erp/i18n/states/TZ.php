<?php

global $states;

$states['TZ'] = [
    'ARUSHA'                => __( 'Arusha', 'erp' ),
    'DARESSALAAM'           => __( 'Dar es Salaam', 'erp' ),
    'DODOMA'                => __( 'Dodoma', 'erp' ),
    'IRINGA'                => __( 'Iringa', 'erp' ),
    'KAGERA'                => __( 'Kagera', 'erp' ),
    'KIGOMA'                => __( 'Kigoma', 'erp' ),
    'KILIMANJARO'           => __( 'Kilimanjaro', 'erp' ),
    'LINDI'                 => __( 'Lindi', 'erp' ),
    'MANYARA'               => __( 'Manyara', 'erp' ),
    'MARA'                  => __( 'Mara', 'erp' ),
    'MBEYA'                 => __( 'Mbeya', 'erp' ),
    'MOROGORO'              => __( 'Morogoro', 'erp' ),
    'MTWARA'                => __( 'Mtwara', 'erp' ),
    'MWANZA'                => __( 'Mwanza', 'erp' ),
    'PEMBANORTH'            => __( 'Pemba North', 'erp' ),
    'PEMBASOUTH'            => __( 'Pemba South', 'erp' ),
    'PWANI'                 => __( 'Pwani', 'erp' ),
    'RUKWA'                 => __( 'Rukwa', 'erp' ),
    'RUVUMA'                => __( 'Ruvuma', 'erp' ),
    'SHINYANGA'             => __( 'Shinyanga', 'erp' ),
    'SINGIDA'               => __( 'Singida', 'erp' ),
    'TABORA'                => __( 'Tabora', 'erp' ),
    'TANGA'                 => __( 'Tanga', 'erp' ),
    'ZANZIBARCENTRAL/SOUTH' => __( 'Zanzibar Central/South', 'erp' ),
    'ZANZIBARNORTH'         => __( 'Zanzibar North', 'erp' ),
    'ZANZIBARURBAN/WEST'    => __( 'Zanzibar Urban/West', 'erp' ),
];

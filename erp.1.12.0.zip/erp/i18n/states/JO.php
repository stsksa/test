<?php

global $states;

$states['JO'] = [
    'AJLUN'     => __( 'Ajlun', 'erp' ),
    "AL'AQABAH" => __( "Al 'Aqabah", 'erp' ),
    "ALBALQA'"  => __( "Al Balqa'", 'erp' ),
    'ALKARAK'   => __( 'Al Karak', 'erp' ),
    'ALMAFRAQ'  => __( 'Al Mafraq', 'erp' ),
    "'AMMAN"    => __( "'Amman", 'erp' ),
    'ATTAFILAH' => __( 'At Tafilah', 'erp' ),
    "AZZARQA'"  => __( "Az Zarqa'", 'erp' ),
    'IRBID'     => __( 'Irbid', 'erp' ),
    'JARASH'    => __( 'Jarash', 'erp' ),
    "MA'AN"     => __( "Ma'an", 'erp' ),
    'MADABA'    => __( 'Madaba', 'erp' ),
];

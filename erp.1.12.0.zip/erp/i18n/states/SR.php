<?php

global $states;

$states['SR'] = [
    'BROKOPONDO' => __( 'Brokopondo', 'erp' ),
    'COMMEWIJNE' => __( 'Commewijne', 'erp' ),
    'CORONIE'    => __( 'Coronie', 'erp' ),
    'MAROWIJNE'  => __( 'Marowijne', 'erp' ),
    'NICKERIE'   => __( 'Nickerie', 'erp' ),
    'PARA'       => __( 'Para', 'erp' ),
    'PARAMARIBO' => __( 'Paramaribo', 'erp' ),
    'SARAMACCA'  => __( 'Saramacca', 'erp' ),
    'SIPALIWINI' => __( 'Sipaliwini', 'erp' ),
    'WANICA'     => __( 'Wanica', 'erp' ),
];

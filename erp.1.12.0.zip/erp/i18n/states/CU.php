<?php

global $states;

$states['CU'] = [
    'CAMAGUEY'         => __( 'Camaguey', 'erp' ),
    'CIEGODEAVILA'     => __( 'Ciego de Avila', 'erp' ),
    'CIENFUEGOS'       => __( 'Cienfuegos', 'erp' ),
    'CIUDADDELAHABANA' => __( 'Ciudad de La Habana', 'erp' ),
    'GRANMA'           => __( 'Granma', 'erp' ),
    'GUANTANAMO'       => __( 'Guantanamo', 'erp' ),
    'HOLGUIN'          => __( 'Holguin', 'erp' ),
    'ISLADELAJUVENTUD' => __( 'Isla de la Juventud', 'erp' ),
    'LAHABANA'         => __( 'La Habana', 'erp' ),
    'LASTUNAS'         => __( 'Las Tunas', 'erp' ),
    'MATANZAS'         => __( 'Matanzas', 'erp' ),
    'PINARDELRIO'      => __( 'Pinar del Rio', 'erp' ),
    'SANCTISPIRITUS'   => __( 'Sancti Spiritus', 'erp' ),
    'SANTIAGODECUBA'   => __( 'Santiago de Cuba', 'erp' ),
    'VILLACLARA'       => __( 'Villa Clara', 'erp' ),
];

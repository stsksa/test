<?php

global $states;

$states['CH'] = [
    'AARGAU'                 => __( 'Aargau', 'erp' ),
    'APPENZELLAUSSER-RHODEN' => __( 'Appenzell Ausser-Rhoden', 'erp' ),
    'APPENZELLINNER-RHODEN'  => __( 'Appenzell Inner-Rhoden', 'erp' ),
    'BASEL-LANDSCHAFT'       => __( 'Basel-Landschaft', 'erp' ),
    'BASEL-STADT'            => __( 'Basel-Stadt', 'erp' ),
    'BERN'                   => __( 'Bern', 'erp' ),
    'FRIBOURG'               => __( 'Fribourg', 'erp' ),
    'GENEVE'                 => __( 'Geneve', 'erp' ),
    'GLARUS'                 => __( 'Glarus', 'erp' ),
    'GRAUBUNDEN'             => __( 'Graubunden', 'erp' ),
    'JURA'                   => __( 'Jura', 'erp' ),
    'LUZERN'                 => __( 'Luzern', 'erp' ),
    'NEUCHATEL'              => __( 'Neuchatel', 'erp' ),
    'NIDWALDEN'              => __( 'Nidwalden', 'erp' ),
    'OBWALDEN'               => __( 'Obwalden', 'erp' ),
    'SANKTGALLEN'            => __( 'Sankt Gallen', 'erp' ),
    'SCHAFFHAUSEN'           => __( 'Schaffhausen', 'erp' ),
    'SCHWYZ'                 => __( 'Schwyz', 'erp' ),
    'SOLOTHURN'              => __( 'Solothurn', 'erp' ),
    'THURGAU'                => __( 'Thurgau', 'erp' ),
    'TICINO'                 => __( 'Ticino', 'erp' ),
    'URI'                    => __( 'Uri', 'erp' ),
    'VALAIS'                 => __( 'Valais', 'erp' ),
    'VAUD'                   => __( 'Vaud', 'erp' ),
    'ZUG'                    => __( 'Zug', 'erp' ),
    'ZURICH'                 => __( 'Zurich', 'erp' ),
];

<?php

global $states;

$states['LR'] = [
    'BOMI'           => __( 'Bomi', 'erp' ),
    'BONG'           => __( 'Bong', 'erp' ),
    'GBARPOLU'       => __( 'Gbarpolu', 'erp' ),
    'GRANDBASSA'     => __( 'Grand Bassa', 'erp' ),
    'GRANDCAPEMOUNT' => __( 'Grand Cape Mount', 'erp' ),
    'GRANDGEDEH'     => __( 'Grand Gedeh', 'erp' ),
    'GRANDKRU'       => __( 'Grand Kru', 'erp' ),
    'LOFA'           => __( 'Lofa', 'erp' ),
    'MARGIBI'        => __( 'Margibi', 'erp' ),
    'MARYLAND'       => __( 'Maryland', 'erp' ),
    'MONTSERRADO'    => __( 'Montserrado', 'erp' ),
    'NIMBA'          => __( 'Nimba', 'erp' ),
    'RIVERCESS'      => __( 'River Cess', 'erp' ),
    'RIVERGEE'       => __( 'River Gee', 'erp' ),
    'SINOE'          => __( 'Sinoe', 'erp' ),
];

<?php

global $states;

$states['AM'] = [
    'ARAGATSOTN'    => __( 'Aragatsotn', 'erp' ),
    'ARARAT'        => __( 'Ararat', 'erp' ),
    'ARMAVIR'       => __( 'Armavir', 'erp' ),
    "GEGHARK'UNIK'" => __( "Geghark'unik'", 'erp' ),
    "KOTAYK'"       => __( "Kotayk'", 'erp' ),
    'LORRI'         => __( 'Lorri', 'erp' ),
    'SHIRAK'        => __( 'Shirak', 'erp' ),
    "SYUNIK'"       => __( "Syunik'", 'erp' ),
    'TAVUSH'        => __( 'Tavush', 'erp' ),
    "VAYOTS'DZOR"   => __( "Vayots' Dzor", 'erp' ),
    'YEREVAN'       => __( 'Yerevan', 'erp' ),
];

<?php

global $states;

$states['GA'] = [
    'ESTUAIRE'        => __( 'Estuaire', 'erp' ),
    'HAUT-OGOOUE'     => __( 'Haut-Ogooue', 'erp' ),
    'MOYEN-OGOOUE'    => __( 'Moyen-Ogooue', 'erp' ),
    'NGOUNIE'         => __( 'Ngounie', 'erp' ),
    'NYANGA'          => __( 'Nyanga', 'erp' ),
    'OGOOUE-IVINDO'   => __( 'Ogooue-Ivindo', 'erp' ),
    'OGOOUE-LOLO'     => __( 'Ogooue-Lolo', 'erp' ),
    'OGOOUE-MARITIME' => __( 'Ogooue-Maritime', 'erp' ),
    'WOLEU-NTEM'      => __( 'Woleu-Ntem', 'erp' ),
];

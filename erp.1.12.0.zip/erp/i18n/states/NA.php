<?php

global $states;

$states['NA'] = [
    'CAPRIVI'      => __( 'Caprivi', 'erp' ),
    'ERONGO'       => __( 'Erongo', 'erp' ),
    'HARDAP'       => __( 'Hardap', 'erp' ),
    'KARAS'        => __( 'Karas', 'erp' ),
    'KHOMAS'       => __( 'Khomas', 'erp' ),
    'KUNENE'       => __( 'Kunene', 'erp' ),
    'OHANGWENA'    => __( 'Ohangwena', 'erp' ),
    'OKAVANGO'     => __( 'Okavango', 'erp' ),
    'OMAHEKE'      => __( 'Omaheke', 'erp' ),
    'OMUSATI'      => __( 'Omusati', 'erp' ),
    'OSHANA'       => __( 'Oshana', 'erp' ),
    'OSHIKOTO'     => __( 'Oshikoto', 'erp' ),
    'OTJOZONDJUPA' => __( 'Otjozondjupa', 'erp' ),
];

<?php

global $states;

$states['CF'] = [
    'BAMINGUI-BANGORAN' => __( 'Bamingui-Bangoran', 'erp' ),
    'BANGUI'            => __( 'Bangui', 'erp' ),
    'BASSE-KOTTO'       => __( 'Basse-Kotto', 'erp' ),
    'HAUTE-KOTTO'       => __( 'Haute-Kotto', 'erp' ),
    'HAUT-MBOMOU'       => __( 'Haut-Mbomou', 'erp' ),
    'KEMO'              => __( 'Kemo', 'erp' ),
    'LOBAYE'            => __( 'Lobaye', 'erp' ),
    'MAMBERE-KADEI'     => __( 'Mambere-Kadei', 'erp' ),
    'MBOMOU'            => __( 'Mbomou', 'erp' ),
    'NANA-GREBIZI'      => __( 'Nana-Grebizi', 'erp' ),
    'NANA-MAMBERE'      => __( 'Nana-Mambere', 'erp' ),
    'OMBELLA-MPOKO'     => __( 'Ombella-Mpoko', 'erp' ),
    'OUAKA'             => __( 'Ouaka', 'erp' ),
    'OUHAM'             => __( 'Ouham', 'erp' ),
    'OUHAM-PENDE'       => __( 'Ouham-Pende', 'erp' ),
    'SANGHA-MBAERE'     => __( 'Sangha-Mbaere', 'erp' ),
    'VAKAGA'            => __( 'Vakaga', 'erp' ),
];

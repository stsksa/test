<?php

global $states;

$states['PG'] = [
    'BOUGAINVILLE'      => __( 'Bougainville', 'erp' ),
    'CENTRAL'           => __( 'Central', 'erp' ),
    'CHIMBU'            => __( 'Chimbu', 'erp' ),
    'EASTERNHIGHLANDS'  => __( 'Eastern Highlands', 'erp' ),
    'EASTNEWBRITAIN'    => __( 'East New Britain', 'erp' ),
    'EASTSEPIK'         => __( 'East Sepik', 'erp' ),
    'ENGA'              => __( 'Enga', 'erp' ),
    'GULF'              => __( 'Gulf', 'erp' ),
    'MADANG'            => __( 'Madang', 'erp' ),
    'MANUS'             => __( 'Manus', 'erp' ),
    'MILNEBAY'          => __( 'Milne Bay', 'erp' ),
    'MOROBE'            => __( 'Morobe', 'erp' ),
    'NATIONALCAPITAL'   => __( 'National Capital', 'erp' ),
    'NEWIRELAND'        => __( 'New Ireland', 'erp' ),
    'NORTHERN'          => __( 'Northern', 'erp' ),
    'SANDAUN'           => __( 'Sandaun', 'erp' ),
    'SOUTHERNHIGHLANDS' => __( 'Southern Highlands', 'erp' ),
    'WESTERN'           => __( 'Western', 'erp' ),
    'WESTERNHIGHLANDS'  => __( 'Western Highlands', 'erp' ),
    'WESTNEWBRITAIN'    => __( 'West New Britain', 'erp' ),
];
